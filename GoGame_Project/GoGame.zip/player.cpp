#include "player.h"
#include <iostream>
#include <cctype>

Player::Player(const std::string &name, char color) : name(name), color(color), score(0) {}

std::string Player::getName() const
{
    return name;
}

char Player::getColor() const
{
    return color;
}

int Player::getScore() const
{
    return score;
}

void Player::addScore(int s)
{
    score += s;
}

HumanPlayer::HumanPlayer(const std::string &name, char color) : Player(name, color) {}

void HumanPlayer::makeMove(int &x, int &y)
{
    std::string input;
    std::cout << getName() << " (" << getColor() << ") - Enter your move (e.g., A3) or P to pass, R to resign: ";
    std::cin >> input;

    if (input == "P" || input == "p")
    {
        x = y = -1;
        return;
    }

    if (input == "R" || input == "r" || input == "resign")
    {
        x = y = -99;
        return;
    }

    if (input.length() >= 2 && std::isalpha(input[0]))
    {
        x = std::toupper(input[0]) - 'A';
        try
        {
            y = std::stoi(input.substr(1)) - 1;
        }
        catch (...)
        {
            x = y = -2;
        }
    }
    else
    {
        x = y = -2;
    }
}
