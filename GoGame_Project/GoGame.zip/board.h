#pragma once
#include <vector>

class Board
{
private:
    std::vector<std::vector<char>> grid;
    std::vector<std::vector<char>> previousGrid;
    int size;
    int blackCaptured;
    int whiteCaptured;

    void removeCaptured(int x, int y, char color);
    bool hasLiberty(int x, int y, char color, std::vector<std::vector<bool>> &visited);
    bool hasLibertySim(int x, int y, char color, std::vector<std::vector<bool>> &visited, const std::vector<std::vector<char>> &state);
    char detectTerritoryOwner(int x, int y, std::vector<std::vector<bool>> &visited);

public:
    Board(int size = 9);
    void display() const;
    bool placeStone(int x, int y, char color);
    char getCell(int x, int y) const;
    int getCaptured(char color) const;
    void calculateTerritory(int &blackTerritory, int &whiteTerritory) const;
};