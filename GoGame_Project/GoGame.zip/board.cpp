#include "board.h"
#include <iostream>
#include <queue>
#include <set>

Board::Board(int size)
    : size(size),
      grid(size, std::vector<char>(size, '.')),
      previousGrid(size, std::vector<char>(size, '.')),
      blackCaptured(0),
      whiteCaptured(0) {}

void Board::display() const
{
    std::cout << "   ";
    for (int col = 0; col < size; ++col)
    {
        std::cout << (col + 1) << " ";
    }
    std::cout << "\n";
    for (int row = 0; row < size; ++row)
    {
        std::cout << static_cast<char>('A' + row) << "  ";
        for (int col = 0; col < size; ++col)
        {
            char cell = grid[row][col];
            if (cell == 'B')
                std::cout << "\033[1;34mB\033[0m ";
            else if (cell == 'W')
                std::cout << "\033[1;31mW\033[0m ";
            else
                std::cout << ". ";
        }
        std::cout << "\n";
    }
}

bool Board::placeStone(int x, int y, char color)
{
    if (x < 0 || y < 0 || x >= size || y >= size)
    {
        std::cout << "Invalid position on the board.\n";
        return false;
    }
    if (grid[x][y] != '.')
    {
        std::cout << "This spot is already occupied!\n";
        return false;
    }

    std::vector<std::vector<char>> testGrid = grid;
    testGrid[x][y] = color;
    char opponent = (color == 'B') ? 'W' : 'B';

    const int dx[4] = {-1, 1, 0, 0};
    const int dy[4] = {0, 0, -1, 1};

    for (int i = 0; i < 4; ++i)
    {
        int nx = x + dx[i];
        int ny = y + dy[i];
        if (nx >= 0 && ny >= 0 && nx < size && ny < size && testGrid[nx][ny] == opponent)
        {
// Create a 2D visited matrix to track which positions have already been checked.
            std::vector<std::vector<bool>> visited(size, std::vector<bool>(size, false));
            if (!hasLibertySim(nx, ny, opponent, visited, testGrid))
            {
                for (int i = 0; i < size; ++i)
                    for (int j = 0; j < size; ++j)
                        if (visited[i][j])
                            testGrid[i][j] = '.';
            }
        }
    }

    if (testGrid == previousGrid)
    {
        std::cout << "Ko rule violation: move would recreate previous board.\n";
        return false;
    }

    previousGrid = grid;
    grid = testGrid;

    for (int i = 0; i < size; ++i)
        for (int j = 0; j < size; ++j)
// Only perform flood fill on unvisited empty cells ('.')
            if (previousGrid[i][j] != '.' && grid[i][j] == '.')
                (previousGrid[i][j] == 'B') ? blackCaptured++ : whiteCaptured++;

    std::vector<std::vector<bool>> selfCheck(size, std::vector<bool>(size, false));
    if (!hasLiberty(x, y, color, selfCheck))
    {
        std::cout << "Invalid move: suicide not allowed.\n";
        grid = previousGrid;
        return false;
    }

    return true;
}

void Board::removeCaptured(int x, int y, char color)
{
// Create a 2D visited matrix to track which positions have already been checked.
    std::vector<std::vector<bool>> visited(size, std::vector<bool>(size, false));
    if (!hasLiberty(x, y, color, visited))
    {
        for (int i = 0; i < size; ++i)
            for (int j = 0; j < size; ++j)
                if (visited[i][j])
                    grid[i][j] = '.';
    }
}

bool Board::hasLiberty(int x, int y, char color, std::vector<std::vector<bool>> &visited)
{
    if (x < 0 || y < 0 || x >= size || y >= size)
        return false;
    if (visited[x][y])
        return false;
    if (grid[x][y] != color)
        return false;

    visited[x][y] = true;

    const int dx[4] = {-1, 1, 0, 0};
    const int dy[4] = {0, 0, -1, 1};

    for (int i = 0; i < 4; ++i)
    {
        int nx = x + dx[i];
        int ny = y + dy[i];
        if (nx >= 0 && ny >= 0 && nx < size && ny < size)
        {
            if (grid[nx][ny] == '.')
                return true;
            if (grid[nx][ny] == color && hasLiberty(nx, ny, color, visited))
                return true;
        }
    }
    return false;
}

bool Board::hasLibertySim(int x, int y, char color, std::vector<std::vector<bool>> &visited, const std::vector<std::vector<char>> &state)
{
    if (x < 0 || y < 0 || x >= size || y >= size)
        return false;
    if (visited[x][y])
        return false;
    if (state[x][y] != color)
        return false;

    visited[x][y] = true;

    const int dx[4] = {-1, 1, 0, 0};
    const int dy[4] = {0, 0, -1, 1};

    for (int i = 0; i < 4; ++i)
    {
        int nx = x + dx[i];
        int ny = y + dy[i];
        if (nx >= 0 && ny >= 0 && nx < size && ny < size)
        {
            if (state[nx][ny] == '.')
                return true;
            if (state[nx][ny] == color && hasLibertySim(nx, ny, color, visited, state))
                return true;
        }
    }
    return false;
}

char Board::getCell(int x, int y) const
{
    return grid[x][y];
}

int Board::getCaptured(char color) const
{
    return (color == 'B') ? blackCaptured : whiteCaptured;
}

// Call flood fill from the current empty cell to determine which color surrounds this area.
char Board::detectTerritoryOwner(int x, int y, std::vector<std::vector<bool>> &visited)
{
    std::queue<std::pair<int, int>> q;
    std::set<char> neighborColors;
    q.push({x, y});
    visited[x][y] = true;
    int dx[4] = {-1, 1, 0, 0};
    int dy[4] = {0, 0, -1, 1};

    while (!q.empty())
    {
        auto [cx, cy] = q.front();
        q.pop();
        for (int d = 0; d < 4; ++d)
        {
            int nx = cx + dx[d];
            int ny = cy + dy[d];
            if (nx >= 0 && ny >= 0 && nx < size && ny < size)
            {
                if (grid[nx][ny] == '.' && !visited[nx][ny])
                {
                    visited[nx][ny] = true;
                    q.push({nx, ny});
                }
                else if (grid[nx][ny] != '.')
                {
                    neighborColors.insert(grid[nx][ny]);
                }
            }
        }
    }

    if (neighborColors.size() == 1)
        return *neighborColors.begin();
    return '.';
}


// This function calculates the total territory of each player.
// It uses flood fill to explore empty areas and determines if they are fully surrounded by one color.
void Board::calculateTerritory(int &blackTerritory, int &whiteTerritory) const
{
    blackTerritory = 0;
    whiteTerritory = 0;
// Create a 2D visited matrix to track which positions have already been checked.
    std::vector<std::vector<bool>> visited(size, std::vector<bool>(size, false));
    for (int i = 0; i < size; ++i)
    {
        for (int j = 0; j < size; ++j)
        {
// Only perform flood fill on unvisited empty cells ('.')
            if (!visited[i][j] && grid[i][j] == '.')
            {
// Call flood fill from the current empty cell to determine which color surrounds this area.
                char owner = const_cast<Board *>(this)->detectTerritoryOwner(i, j, visited);
                if (owner == 'B')
// Count the area as black territory if it is fully enclosed by black stones.
                    blackTerritory++;
                else if (owner == 'W')
// Count the area as white territory if it is fully enclosed by white stones.
                    whiteTerritory++;
            }
        }
    }
}