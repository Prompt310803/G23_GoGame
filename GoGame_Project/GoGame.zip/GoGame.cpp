#include "game_manager.h"
#include <iostream>
#include <string>

int main()
{
    while (true)
    {
        GameManager game;
        game.startGame();

        std::string command;
        std::cout << "Play again? (type 'again' to restart): ";
        std::cin >> command;

        if (command != "again")
        {
            std::cout << "Thanks for playing!\n";
            break;
        }
    }

    return 0;
}