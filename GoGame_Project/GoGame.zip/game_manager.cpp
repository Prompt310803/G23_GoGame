#include "game_manager.h"
#include <iostream>

GameManager::GameManager()
{
    player1 = new HumanPlayer("Player 1", 'B');
    player2 = new HumanPlayer("Player 2", 'W');
    currentTurn = 0;
    passCount = 0;
}

GameManager::~GameManager()
{
    delete player1;
    delete player2;
}

void GameManager::startGame()
{
    std::cout << "=== Go Game Start ===\n";
    bool running = true;
    bool resigned = false;

    while (running)
    {
        board.display();
        Player *currentPlayer = (currentTurn % 2 == 0) ? player1 : player2;
        Player *opponentPlayer = (currentTurn % 2 == 0) ? player2 : player1;

        int x, y;
        currentPlayer->makeMove(x, y);

        // Check for resign
        if (x == -99 && y == -99)
        {
            std::cout << currentPlayer->getName() << " resigned!\n";
            std::cout << "Winner: " << opponentPlayer->getName() << "\n";
            resigned = true;
            break;
        }

        if (x == -2 || y == -2)
        {
            std::cout << "Invalid input! Please try again.\n";
            continue;
        }
        else if (x == -1 && y == -1)
        {
            std::cout << currentPlayer->getName() << " passed their turn.\n";
            passCount++;
            currentTurn++;
        }
        else
        {
            bool placeSuccess = board.placeStone(x, y, currentPlayer->getColor());
            if (!placeSuccess)
            {
                continue;
            }
            passCount = 0;
            currentTurn++;
        }

        int blackTerritory = 0, whiteTerritory = 0;
        board.calculateTerritory(blackTerritory, whiteTerritory);

        int blackCaptured = board.getCaptured('W');
        int whiteCaptured = board.getCaptured('B');

        double blackScore = blackTerritory + blackCaptured;
        double whiteScore = whiteTerritory + whiteCaptured + 6.5;

        std::cout << "Current Score:\n";
        std::cout << player1->getName() << ": " << blackScore << " (Territory: " << blackTerritory << ", Captured: " << blackCaptured << ")\n";
        std::cout << player2->getName() << ": " << whiteScore << " (Territory: " << whiteTerritory << ", Captured: " << whiteCaptured << ", Komi: 6.5)\n\n";

        if (passCount >= 2)
        {
            std::cout << "Both players passed. Game over.\n";
            break;
        }
    }

    if (!resigned)
    {
        std::cout << "=== Final Score ===\n";
        int blackTerritory = 0, whiteTerritory = 0;
        board.calculateTerritory(blackTerritory, whiteTerritory);

        int blackCaptured = board.getCaptured('W');
        int whiteCaptured = board.getCaptured('B');

        double blackScore = blackTerritory + blackCaptured;
        double whiteScore = whiteTerritory + whiteCaptured + 6.5;

        std::cout << player1->getName() << ": " << blackScore << " (Territory: " << blackTerritory << ", Captured: " << blackCaptured << ")\n";
        std::cout << player2->getName() << ": " << whiteScore << " (Territory: " << whiteTerritory << ", Captured: " << whiteCaptured << ", Komi: 6.5)\n";

        if (blackScore > whiteScore)
        {
            std::cout << "Winner: " << player1->getName() << "\n";
        }
        else if (whiteScore > blackScore)
        {
            std::cout << "Winner: " << player2->getName() << "\n";
        }
        else
        {
            std::cout << "Draw!\n";
        }
    }
}
